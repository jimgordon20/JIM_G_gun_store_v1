fx_version 'adamant'
game 'gta5'

name "petshop_map"
description 'The better version of petshop_map and moved.'
author "moved and re-edit by BaziForYou#9907 original map made by K4MB1#4372"
version '1.1'


this_is_a_map 'yes'

client_script "@Antich/acloader.lua"